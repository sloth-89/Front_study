
  $(function(){
  $('div').click(function(){ 
      $(this).css('animation-name','direction');
  });
});
